package io.muzoo.ssc.project.backend.auth;

public class HomePageController {
}
